"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.IConnectionStatus = exports.IActionType = exports.IPayloadType = exports.IChattingType = exports.IMessageType = exports.IChatToolType = exports.ILogLevel = exports.IProtocol = void 0;
/* eslint-disable no-unused-vars */
var IProtocol;
(function (IProtocol) {
    IProtocol["HTTP"] = "http";
    IProtocol["HTTPS"] = "https";
    IProtocol["WS"] = "ws";
    IProtocol["WSS"] = "wss";
})(IProtocol = exports.IProtocol || (exports.IProtocol = {}));
var ILogLevel;
(function (ILogLevel) {
    ILogLevel["ERROR"] = "error";
    ILogLevel["WARN"] = "warn";
    ILogLevel["INFO"] = "info";
    ILogLevel["VERBOSE"] = "verbose";
    ILogLevel["DEBUG"] = "debug";
    ILogLevel["SILLY"] = "silly";
})(ILogLevel = exports.ILogLevel || (exports.ILogLevel = {}));
var IChatToolType;
(function (IChatToolType) {
    IChatToolType["MATTERMOST"] = "mattermost";
    IChatToolType["SLACK"] = "slack";
    IChatToolType["MSTEAMS"] = "msteams";
})(IChatToolType = exports.IChatToolType || (exports.IChatToolType = {}));
var IMessageType;
(function (IMessageType) {
    IMessageType["PLAIN_TEXT"] = "plainText";
    IMessageType["MATTERMOST_ATTACHMENT"] = "mattermost.attachment";
    IMessageType["MATTERMOST_DIALOG_OPEN"] = "mattermost.dialog.open";
    IMessageType["SLACK_BLOCK"] = "slack.block";
    IMessageType["SLACK_VIEW_OPEN"] = "slack.view.open";
    IMessageType["SLACK_VIEW_UPDATE"] = "slack.view.update";
    IMessageType["MSTEAMS_ADAPTIVE_CARD"] = "msteams.adaptiveCard";
    IMessageType["MSTEAMS_DIALOG_OPEN"] = "msteams.dialog.open";
})(IMessageType = exports.IMessageType || (exports.IMessageType = {}));
var IChattingType;
(function (IChattingType) {
    IChattingType["PERSONAL"] = "personal";
    IChattingType["PUBLIC_CHANNEL"] = "publicChannel";
    IChattingType["PRIVATE_CHANNEL"] = "privateChannel";
    IChattingType["GROUP"] = "group";
    IChattingType["UNKNOWN"] = "unknown";
})(IChattingType = exports.IChattingType || (exports.IChattingType = {}));
var IPayloadType;
(function (IPayloadType) {
    IPayloadType["MESSAGE"] = "message";
    IPayloadType["EVENT"] = "event";
})(IPayloadType = exports.IPayloadType || (exports.IPayloadType = {}));
var IActionType;
(function (IActionType) {
    IActionType["BUTTON_CLICK"] = "button.click";
    IActionType["DROPDOWN_SELECT"] = "dropdown.select";
    IActionType["DIALOG_OPEN"] = "dialog.open";
    IActionType["DIALOG_SUBMIT"] = "dialog.submit";
    IActionType["UNSUPPORTED"] = "unsupported";
})(IActionType = exports.IActionType || (exports.IActionType = {}));
var IConnectionStatus;
(function (IConnectionStatus) {
    IConnectionStatus["ALIVE"] = "alive";
    IConnectionStatus["NOT_CONNECTED"] = "not_connected";
    IConnectionStatus["CONNECTING"] = "connecting";
    IConnectionStatus["RECONNECTING"] = "reconnecting";
    IConnectionStatus["CLOSED"] = "closed";
    IConnectionStatus["CLOSING"] = "closing";
    IConnectionStatus["EXPIRED"] = "expired";
    IConnectionStatus["ERROR"] = "error";
})(IConnectionStatus = exports.IConnectionStatus || (exports.IConnectionStatus = {}));
