import type { Application } from 'express';
import type { Receiver } from '@slack/bolt';
import { CommonBot } from '../CommonBot';
export { TaskModuleTaskInfo, Attachment } from 'botbuilder';
export declare const enum IProtocol {
    HTTP = "http",
    HTTPS = "https",
    WS = "ws",
    WSS = "wss"
}
export declare const enum ILogLevel {
    ERROR = "error",
    WARN = "warn",
    INFO = "info",
    VERBOSE = "verbose",
    DEBUG = "debug",
    SILLY = "silly"
}
export declare const enum IChatToolType {
    MATTERMOST = "mattermost",
    SLACK = "slack",
    MSTEAMS = "msteams"
}
export declare const enum IMessageType {
    PLAIN_TEXT = "plainText",
    MATTERMOST_ATTACHMENT = "mattermost.attachment",
    MATTERMOST_DIALOG_OPEN = "mattermost.dialog.open",
    SLACK_BLOCK = "slack.block",
    SLACK_VIEW_OPEN = "slack.view.open",
    SLACK_VIEW_UPDATE = "slack.view.update",
    MSTEAMS_ADAPTIVE_CARD = "msteams.adaptiveCard",
    MSTEAMS_DIALOG_OPEN = "msteams.dialog.open"
}
export declare const enum IChattingType {
    PERSONAL = "personal",
    PUBLIC_CHANNEL = "publicChannel",
    PRIVATE_CHANNEL = "privateChannel",
    GROUP = "group",
    UNKNOWN = "unknown"
}
export declare const enum IPayloadType {
    MESSAGE = "message",
    EVENT = "event"
}
export declare const enum IActionType {
    BUTTON_CLICK = "button.click",
    DROPDOWN_SELECT = "dropdown.select",
    DIALOG_OPEN = "dialog.open",
    DIALOG_SUBMIT = "dialog.submit",
    UNSUPPORTED = "unsupported"
}
export declare const enum IConnectionStatus {
    ALIVE = "alive",
    NOT_CONNECTED = "not_connected",
    CONNECTING = "connecting",
    RECONNECTING = "reconnecting",
    CLOSED = "closed",
    CLOSING = "closing",
    EXPIRED = "expired",
    ERROR = "error"
}
export interface IMessage {
    type: IMessageType;
    message: any;
    mentions?: Record<string, any>[];
}
export interface IBotOption {
    messagingApp: IMessagingApp;
    chatTool: IChatTool;
}
export interface ILogOption {
    filePath: string;
    level: ILogLevel;
    maximumSize: number;
    maximumFile: number;
}
export interface IAppOption extends IHttpEndpoint {
    tlsKey: string;
    tlsCert: string;
}
export interface IHttpEndpoint {
    protocol: IProtocol;
    hostName: string;
    port: number;
    basePath: string;
}
export interface IMessagingApp {
    option: IAppOption;
    app: Application;
}
export interface IChatTool {
    type: IChatToolType;
    option: IMattermostOption | ISlackOption | IMsteamsOption;
}
export interface IMattermostOption {
    protocol: IProtocol;
    hostName: string;
    port: number;
    basePath: string;
    tlsCertificate: string;
    teamUrl: string;
    botUserName: string;
    botAccessToken: string;
}
export interface ISlackOption {
    botUserName: string;
    signingSecret: string;
    endpoints: string | Record<string, any>;
    receiver: Receiver;
    token: string;
    logLevel: string;
    socketMode: boolean;
    appToken: string;
}
export interface IMsteamsOption {
    botUserName: string;
    botId: string;
    botPassword: string;
}
export interface IMessageMatcherFunction {
    (chatContextData: IChatContextData): boolean;
}
export interface IMessageHandlerFunction {
    (chatContextData: IChatContextData): Promise<void>;
}
export interface IMessageMatcher {
    matcher: IMessageMatcherFunction;
    handlers: IMessageHandlerFunction[];
}
export interface IMessageHandlerIndex {
    matcherIndex: number;
    handlerIndex: number;
}
export interface IRoute {
    path: string;
    handler: IRouteHandlerFunction;
}
export interface IRouteHandlerFunction {
    (chatContextData: IChatContextData): Promise<void | Record<string, any>>;
}
export interface IUser {
    id: string;
    name: string;
    email: string;
}
export interface IChatContextData {
    payload: IPayload;
    context: IContext;
    extraData?: any;
}
export interface IPayload {
    type: IPayloadType;
    data: string | IEvent;
}
export interface IContext {
    chatting: IChattingContext;
    chatTool: any;
}
export interface IChatToolContext {
}
export interface IChattingContext {
    bot: CommonBot;
    type: IChattingType;
    user: IUser;
    channel: IName;
    team: IName;
    tenant: IName;
}
export interface IEvent {
    pluginId: string;
    action: IAction;
}
export interface IAction {
    id: string;
    type: IActionType;
    token: string;
}
export interface IName {
    id: string;
    name: string;
}
export interface IChannel {
    id: string;
    name: string;
    chattingType: IChattingType;
}
export interface IBotLimit {
    messageMaxLength: number;
}
export interface IMattermostBotLimit extends IBotLimit {
}
export interface ISlackBotLimit extends IBotLimit {
    blockIdMaxLength: number;
    actionBlockElementsMaxNumber: number;
    contextBlockElementsMaxNumber: number;
    headerBlockTextMaxLength: number;
    imageBlockUrlMaxLength: number;
    imageBlockAltTextMaxLength: number;
    imageBlockTitleTextMaxLength: number;
    inputBlockLabelTextMaxLength: number;
    inputBlockHintTextMaxLength: number;
    sectionBlockTextMaxLength: number;
    sectionBlockFieldsMaxNumber: number;
    sectionBlockFieldsTextMaxLength: number;
    videoBlockAuthorNameMaxLength: number;
    videoBlockTitleTextMaxLength: number;
}
export interface IMsteamsBotLimit extends IBotLimit {
    fileAttachmentMaxNumber: number;
}
