import type { IMessageMatcher, IMessageMatcherFunction, IMessageHandlerFunction, IMessageHandlerIndex } from './types';
export declare class MessageMatcher {
    private matchers;
    constructor();
    addMatcher(messageMatcher: IMessageMatcherFunction, messageHandler: IMessageHandlerFunction): void;
    getMatchers(): IMessageMatcher[];
    indexOfMatcher(messageMatcher: IMessageMatcherFunction): number;
    hasMatcher(messageMatcher: IMessageMatcherFunction): boolean;
    addHandler(messageMatcher: IMessageMatcherFunction, messageHandler: IMessageHandlerFunction): void;
    hasHandler(messageHandler: IMessageHandlerFunction): boolean;
    getHandlers(messageMatcher: IMessageMatcherFunction): IMessageHandlerFunction[];
    indexOfHandler(messageHandler: IMessageHandlerFunction): IMessageHandlerIndex;
}
