import { IMaskingPattern } from '../types';
export declare class Util {
    static dumpObject(obj: Record<string, any>, depth?: number): string;
    static dumpRequest(req: any, formatted?: boolean, includeAllProperties?: boolean): string;
    static concatLines(text: string): string;
    static dumpResponse(res: any, formatted?: boolean, includeAllProperties?: boolean): string;
    static maskSensitiveInfo(text: string, pattern?: IMaskingPattern): string;
}
