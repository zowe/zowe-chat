import { BotLimit } from '../../BotLimit';
export declare class MattermostBotLimit extends BotLimit {
    constructor();
}
