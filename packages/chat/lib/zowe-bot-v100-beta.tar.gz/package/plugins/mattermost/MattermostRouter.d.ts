import { IRouteHandlerFunction } from '../../types';
import type { Request, Response } from 'express';
import { CommonBot } from '../../CommonBot';
import { Router } from '../../Router';
export declare class MattermostRouter extends Router {
    constructor(bot: CommonBot);
    route(path: string, handler: IRouteHandlerFunction): Promise<void>;
    processAction(req: Request, res: Response): Promise<void>;
}
