"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MattermostRouter = void 0;
const Router_1 = require("../../Router");
const Logger_1 = require("../../utils/Logger");
const logger = Logger_1.Logger.getInstance();
class MattermostRouter extends Router_1.Router {
    // Constructor
    constructor(bot) {
        super(bot);
        // Bind this pointer
        this.route = this.route.bind(this);
        this.processAction = this.processAction.bind(this);
    }
    // Run router
    route(path, handler) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.route, this);
            try {
                // Set router
                this.router = {
                    path: path,
                    handler: handler,
                };
                // Get bot option
                const option = this.bot.getOption();
                // Set router
                yield option.messagingApp.app.post(this.router.path, this.processAction);
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.route, this);
            }
        });
    }
    // Process user interactive actions e.g. button clicks, menu selects.
    processAction(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.processAction, this);
            try {
                //  Set root_id to chatToolContext, so the response could be displayed in thread.
                const payload = req.body;
                logger.debug(`Action request body is ${JSON.stringify(payload)}`);
                // Get  event
                const event = {
                    'pluginId': '',
                    'action': {
                        'id': '',
                        'type': null,
                        'token': '',
                    },
                };
                if (payload.type === 'dialog_submission') {
                    // 204 will indicate that the dialog_submission have been received.
                    res.sendStatus(204);
                    // Set event
                    const segments = payload.state.split(':');
                    if (segments.length >= 3) {
                        event.pluginId = segments[0];
                        event.action.id = segments[1];
                        event.action.token = segments[2];
                    }
                    else {
                        logger.error(`The data format of state is wrong!\n state=${payload.state}`);
                    }
                    event.action.type = "dialog.submit" /* IActionType.DIALOG_SUBMIT */;
                }
                else {
                    // Must send {} back to Mattermost server, otherwise dialog could not be opened successfully.
                    // It works fine with interactive component: button and select.
                    res.send({});
                    // Set event
                    event.pluginId = payload.context.pluginId;
                    event.action.id = payload.context.action.id;
                    event.action.token = payload.context.action.token;
                    if (payload.type === 'select') {
                        event.action.type = "dropdown.select" /* IActionType.DROPDOWN_SELECT */;
                    }
                    else if (payload.type === 'button') {
                        if (payload.context.action.type !== undefined) {
                            event.action.type = payload.context.action.type;
                        }
                        else {
                            if (payload.context.action.id.startsWith('DIALOG_OPEN_')) {
                                event.action.type = "dialog.open" /* IActionType.DIALOG_OPEN */;
                            }
                            else {
                                event.action.type = "button.click" /* IActionType.BUTTON_CLICK */;
                            }
                        }
                    }
                    else {
                        event.action.type = "unsupported" /* IActionType.UNSUPPORTED */;
                        logger.error(`Unsupported Mattermost interactive component: ${payload.type}`);
                    }
                }
                let rootId = '';
                if (payload.context !== undefined && payload.context.rootId !== undefined && payload.context.rootId !== '') {
                    rootId = payload.context.rootId;
                }
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                const chatToolContext = {
                    'channelId': payload.channel_id,
                    'rootId': rootId,
                    'body': payload,
                };
                const middleware = this.bot.getMiddleware();
                const user = yield middleware.getUserById(payload.user_id);
                logger.debug(`user is ${JSON.stringify(user)}`);
                const channel = yield middleware.getChannelById(payload.channel_id);
                logger.debug(`channel is ${JSON.stringify(channel)}`);
                const chatContextData = {
                    'payload': {
                        'type': "event" /* IPayloadType.EVENT */,
                        'data': event,
                    },
                    'context': {
                        'chatting': {
                            'bot': this.bot,
                            'type': channel.chattingType,
                            'user': {
                                'id': payload.user_id,
                                'name': user ? user.name : '',
                                'email': user ? user.email : '',
                            },
                            'channel': {
                                'id': payload.channel_id,
                                'name': payload.channel_name,
                            },
                            'team': {
                                'id': payload.team_id,
                                'name': payload.team_domain,
                            },
                            'tenant': {
                                'id': '',
                                'name': '',
                            },
                        },
                        'chatTool': chatToolContext,
                    },
                };
                this.router.handler(chatContextData);
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.processAction, this);
            }
        });
    }
}
exports.MattermostRouter = MattermostRouter;
