import { BotLimit } from '../../BotLimit';
export declare class MsteamsBotLimit extends BotLimit {
    constructor();
}
