import { IMessageHandlerFunction, IMessageMatcherFunction } from '../../types';
import { CommonBot } from '../../CommonBot';
import { Listener } from '../../Listener';
export declare class MsteamsListener extends Listener {
    constructor(bot: CommonBot);
    listen(matcher: IMessageMatcherFunction, handler: IMessageHandlerFunction): Promise<void>;
}
