import type { IRouteHandlerFunction } from '../../types';
import { CommonBot } from '../../CommonBot';
import { Router } from '../../Router';
export declare class MsteamsRouter extends Router {
    constructor(bot: CommonBot);
    route(path: string, handler: IRouteHandlerFunction): Promise<void>;
}
