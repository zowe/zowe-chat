"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MsteamsRouter = void 0;
const Router_1 = require("../../Router");
const Logger_1 = require("../../utils/Logger");
const MsteamsMiddleware_1 = require("./MsteamsMiddleware");
const logger = Logger_1.Logger.getInstance();
class MsteamsRouter extends Router_1.Router {
    // Constructor
    constructor(bot) {
        super(bot);
        // Bind this pointer
        this.route = this.route.bind(this);
    }
    // Run router
    route(path, handler) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.route, this);
            try {
                // Check and set middleware
                let middleware = this.bot.getMiddleware();
                if (middleware === null) {
                    middleware = new MsteamsMiddleware_1.MsteamsMiddleware(this.bot);
                    this.bot.setMiddleware(middleware);
                    yield middleware.run();
                }
                // Set router
                this.router = {
                    path: path,
                    handler: handler,
                };
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.route, this);
            }
        });
    }
}
exports.MsteamsRouter = MsteamsRouter;
