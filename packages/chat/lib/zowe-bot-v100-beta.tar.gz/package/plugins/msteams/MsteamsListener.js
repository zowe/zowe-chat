"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MsteamsListener = void 0;
const Listener_1 = require("../../Listener");
const Logger_1 = require("../../utils/Logger");
const MsteamsMiddleware_1 = require("./MsteamsMiddleware");
const logger = Logger_1.Logger.getInstance();
class MsteamsListener extends Listener_1.Listener {
    // Constructor
    constructor(bot) {
        super(bot);
        // Bind this pointer
        this.listen = this.listen.bind(this);
    }
    // Run listener
    listen(matcher, handler) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.listen, this);
            try {
                // Check and set middleware
                let middleware = this.bot.getMiddleware();
                if (middleware === null) {
                    middleware = new MsteamsMiddleware_1.MsteamsMiddleware(this.bot);
                    this.bot.setMiddleware(middleware);
                    yield middleware.run();
                }
                // Set matcher
                this.messageMatcher.addMatcher(matcher, handler);
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.listen, this);
            }
        });
    }
}
exports.MsteamsListener = MsteamsListener;
