import { ExpressReceiver, ExpressReceiverOptions } from '@slack/bolt';
import { Application } from 'express';
export declare class Receiver extends ExpressReceiver {
    constructor(expressReceiverOptions: ExpressReceiverOptions);
    setApp(messagingApp: Application): void;
}
