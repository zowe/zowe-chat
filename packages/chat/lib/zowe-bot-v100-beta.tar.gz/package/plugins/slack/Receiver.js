"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.Receiver = void 0;
const bolt_1 = require("@slack/bolt");
const Logger_1 = require("../../utils/Logger");
const logger = Logger_1.Logger.getInstance();
class Receiver extends bolt_1.ExpressReceiver {
    constructor(expressReceiverOptions) {
        super(expressReceiverOptions);
    }
    // Replace the default app and use the router
    setApp(messagingApp) {
        logger.start(this.setApp, this);
        try {
            this.app = messagingApp;
            this.app.use(this.router);
        }
        catch (err) {
            // Print exception stack
            logger.error(logger.getErrorStack(new Error(err.name), err));
        }
        finally {
            // Print end log
            logger.end(this.setApp, this);
        }
    }
}
exports.Receiver = Receiver;
