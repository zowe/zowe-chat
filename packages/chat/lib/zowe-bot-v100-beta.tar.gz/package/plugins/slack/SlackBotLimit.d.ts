import { BotLimit } from '../../BotLimit';
export declare class SlackBotLimit extends BotLimit {
    constructor();
}
