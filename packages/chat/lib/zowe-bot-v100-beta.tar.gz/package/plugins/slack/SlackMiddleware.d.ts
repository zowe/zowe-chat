import { IChatContextData, IMessage, IUser, IChannel } from '../../types';
import type { SlackEventMiddlewareArgs, SlackViewMiddlewareArgs, AllMiddlewareArgs, SlackActionMiddlewareArgs } from '@slack/bolt';
import { WebClient } from '@slack/web-api';
import { CommonBot } from '../../CommonBot';
import { Middleware } from '../../Middleware';
export declare class SlackMiddleware extends Middleware {
    private app;
    private botName;
    private users;
    private channels;
    constructor(bot: CommonBot);
    run(): Promise<void>;
    processMessage(slackEvent: SlackEventMiddlewareArgs<'message'> & AllMiddlewareArgs): Promise<void>;
    processAction(slackEvent: SlackActionMiddlewareArgs & AllMiddlewareArgs): Promise<void>;
    processViewAction(slackEvent: SlackViewMiddlewareArgs & AllMiddlewareArgs): Promise<void>;
    send(chatContextData: IChatContextData, messages: IMessage[]): Promise<void>;
    getUser(id: string): IUser;
    addUser(id: string, user: IUser): boolean;
    getChannelById(id: string, slackWebClient: WebClient): Promise<IChannel>;
}
