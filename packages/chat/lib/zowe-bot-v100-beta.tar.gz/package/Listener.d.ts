import type { IMessageHandlerFunction, IMessageMatcherFunction } from './types';
import { CommonBot } from './CommonBot';
import { MessageMatcher } from './MessageMatcher';
export declare class Listener {
    protected bot: CommonBot;
    protected messageMatcher: MessageMatcher;
    constructor(bot: CommonBot);
    listen(matcher: IMessageMatcherFunction, handler: IMessageHandlerFunction): Promise<void>;
    getMessageMatcher(): MessageMatcher;
}
