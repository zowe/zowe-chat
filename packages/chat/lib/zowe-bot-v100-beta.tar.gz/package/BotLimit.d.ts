import { IBotLimit, IMattermostBotLimit, IMsteamsBotLimit, ISlackBotLimit } from './types';
export declare class BotLimit {
    protected limit: IBotLimit | IMattermostBotLimit | ISlackBotLimit | IMsteamsBotLimit;
    constructor();
    getLimit(): IBotLimit | IMattermostBotLimit | ISlackBotLimit | IMsteamsBotLimit;
}
