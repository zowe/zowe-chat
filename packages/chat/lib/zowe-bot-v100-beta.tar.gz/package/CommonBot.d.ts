import { IBotOption, IChatContextData, IMattermostBotLimit, IMessage, IMessageHandlerFunction, IMessageMatcherFunction, IMsteamsBotLimit, IRouteHandlerFunction, ISlackBotLimit } from './types';
import { Listener } from './Listener';
import { Router } from './Router';
import { Middleware } from './Middleware';
export declare class CommonBot {
    private option;
    private limit;
    private middleware;
    private listeners;
    private router;
    constructor(option: IBotOption);
    getOption(): IBotOption;
    setOption(option: IBotOption): void;
    getLimit(): IMattermostBotLimit | ISlackBotLimit | IMsteamsBotLimit;
    getMiddleware(): Middleware;
    setMiddleware(middleware: Middleware): void;
    listen(matcher: IMessageMatcherFunction, handler: IMessageHandlerFunction): Promise<void>;
    getListeners(): Listener[];
    addListener(listener: Listener): void;
    route(basePath: string, handler: IRouteHandlerFunction): Promise<void>;
    geRouter(): Router;
    send(chatContextData: IChatContextData, messages: IMessage[]): Promise<void>;
}
