"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommonBot = void 0;
const Logger_1 = require("./utils/Logger");
const fs_1 = __importDefault(require("fs"));
const MattermostBotLimit_1 = require("./plugins/mattermost/MattermostBotLimit");
const SlackBotLimit_1 = require("./plugins/slack/SlackBotLimit");
const MsteamsBotLimit_1 = require("./plugins/msteams/MsteamsBotLimit");
const logger = Logger_1.Logger.getInstance();
class CommonBot {
    // Constructor
    constructor(option) {
        this.option = option;
        logger.info(`Bot option: ${JSON.stringify(this.option, null, 4)}`);
        // Create Limit instance
        if (this.option.chatTool.type === "mattermost" /* IChatToolType.MATTERMOST */) {
            this.limit = new MattermostBotLimit_1.MattermostBotLimit();
        }
        else if (this.option.chatTool.type === "slack" /* IChatToolType.SLACK */) {
            this.limit = new SlackBotLimit_1.SlackBotLimit();
        }
        else if (this.option.chatTool.type === "msteams" /* IChatToolType.MSTEAMS */) {
            this.limit = new MsteamsBotLimit_1.MsteamsBotLimit();
        }
        else {
            this.limit = null;
        }
        this.middleware = null;
        this.listeners = [];
        this.router = null;
        this.listen = this.listen.bind(this);
        this.route = this.route.bind(this);
        this.send = this.send.bind(this);
    }
    // Get option
    getOption() {
        return this.option;
    }
    // Set option
    setOption(option) {
        this.option = option;
    }
    // Get limit
    getLimit() {
        if (this.limit !== null) {
            return this.limit.getLimit();
        }
        else {
            return null;
        }
    }
    // Get middleware
    getMiddleware() {
        return this.middleware;
    }
    // Set middleware
    setMiddleware(middleware) {
        this.middleware = middleware;
    }
    // Listen all messages send to bot
    listen(matcher, handler) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.listen, this);
            try {
                // Get chat tool type
                const chatToolType = this.option.chatTool.type;
                // Create listener
                let listener = null;
                const pluginFileName = `${chatToolType.substring(0, 1).toUpperCase()}${chatToolType.substring(1)}Listener`;
                logger.info(`Loading listener ${chatToolType}/${pluginFileName} ...`);
                if (fs_1.default.existsSync(`${__dirname}/plugins/${chatToolType}`) === false) {
                    logger.error(`Unsupported chat tool: ${chatToolType}`);
                    throw new Error(`Unsupported chat tool`);
                }
                else {
                    if (fs_1.default.existsSync(`${__dirname}/plugins/${chatToolType}/${pluginFileName}.js`) === false) {
                        logger.error(`The listener file "${__dirname}/plugins/${chatToolType}/${pluginFileName}.js" does not exist!`);
                        throw new Error(`The required listener file "${__dirname}/plugins/${chatToolType}/${pluginFileName}.js" does not exist!`);
                    }
                    else {
                        const ChatToolListener = require(`./plugins/${chatToolType}/${pluginFileName}`);
                        listener = new ChatToolListener[pluginFileName](this);
                    }
                }
                this.listeners.push(listener);
                // Listen
                yield listener.listen(matcher, handler);
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.listen, this);
            }
        });
    }
    // Get listeners
    getListeners() {
        return this.listeners;
    }
    // Add listener
    addListener(listener) {
        this.listeners.push(listener);
    }
    // Set webhook router
    route(basePath, handler) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.route, this);
            try {
                // Get chat tool type
                const chatToolType = this.option.chatTool.type;
                // Create router
                const pluginFileName = `${chatToolType.substring(0, 1).toUpperCase()}${chatToolType.substring(1)}Router`;
                logger.info(`Loading router ${chatToolType}/${pluginFileName} ...`);
                if (fs_1.default.existsSync(`${__dirname}/plugins/${chatToolType}`) === false) {
                    logger.error(`Unsupported chat tool: ${chatToolType}`);
                    throw new Error(`Unsupported chat tool`);
                }
                else {
                    if (fs_1.default.existsSync(`${__dirname}/plugins/${chatToolType}/${pluginFileName}.js`) === false) {
                        logger.error(`The router file "${__dirname}/plugins/${chatToolType}/${pluginFileName}.js" does not exist!`);
                        throw new Error(`The required router file "${__dirname}/plugins/${chatToolType}/${pluginFileName}.js" does not exist!`);
                    }
                    else {
                        const ChatToolRouter = require(`./plugins/${chatToolType}/${pluginFileName}`);
                        this.router = new ChatToolRouter[pluginFileName](this);
                    }
                }
                // Run router
                yield this.router.route(basePath, handler);
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.route, this);
            }
        });
    }
    // Get router
    geRouter() {
        return this.router;
    }
    // Send message to channel
    sendDirectMessage(chatContextData, messages) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.sendDirectMessage, this);
            try {
                yield this.middleware.sendDirectMessage(chatContextData, messages);
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.send, this);
            }
        });
    }
    // Send message to channel
    send(chatContextData, messages) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.send, this);
            try {
                yield this.middleware.send(chatContextData, messages);
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.send, this);
            }
        });
    }
}
exports.CommonBot = CommonBot;
