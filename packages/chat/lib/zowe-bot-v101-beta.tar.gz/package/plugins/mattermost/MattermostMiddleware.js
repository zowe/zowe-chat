"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MattermostMiddleware = void 0;
const Middleware_1 = require("../../Middleware");
const Logger_1 = require("../../utils/Logger");
const MattermostClient_1 = require("./MattermostClient");
const Util_1 = require("../../utils/Util");
const logger = Logger_1.Logger.getInstance();
class MattermostMiddleware extends Middleware_1.Middleware {
    // Constructor
    constructor(bot) {
        super(bot);
        this.client = null;
        this.botUser = null;
        this.users = new Map();
        // Bind this pointer
        this.run = this.run.bind(this);
        this.updateBotUser = this.updateBotUser.bind(this);
        this.processMessage = this.processMessage.bind(this);
        this.send = this.send.bind(this);
        this.getUserById = this.getUserById.bind(this);
        this.addUser = this.addUser.bind(this);
        this.getChannelById = this.getChannelById.bind(this);
        // Get option
        const option = this.bot.getOption();
        if (option.chatTool.type !== "mattermost" /* IChatToolType.MATTERMOST */) {
            logger.error(`Wrong chat tool type set in bot option: ${option.chatTool.type}`);
            throw new Error(`Wrong chat tool type`);
        }
    }
    // Run middleware
    run() {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.run, this);
            try {
                const mattermostOption = (this.bot.getOption().chatTool.option);
                this.client = new MattermostClient_1.MattermostClient(this, mattermostOption);
                if (mattermostOption.botAccessToken != null) {
                    yield this.client.connect();
                }
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.run, this);
            }
        });
    }
    sendDirectMessage(chatContextData, messages) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.sendDirectMessage, this);
            try {
                logger.debug("Creating a dm chat channel");
                const dmChannel = yield this.client.createDmChannel(chatContextData.context.chatting.user);
                // Get chat context data
                logger.debug(`Chat tool data sent to Mattermost server: ${Util_1.Util.dumpObject(chatContextData.context.chatTool, 2)}`);
                for (const msg of messages) {
                    // Process view to open dialog.
                    if (msg.type === "mattermost.dialog.open" /* IMessageType.MATTERMOST_DIALOG_OPEN */) {
                        yield this.client.openDialog(msg.message);
                        break;
                    }
                    // Send message back to dm channel
                    if (chatContextData.context.chatTool !== null) { // Conversation message
                        logger.info('Send conversation message ...');
                        this.client.sendMessage(msg.message, dmChannel.id, chatContextData.context.chatTool.rootId);
                    }
                    else {
                        // Proactive message
                        logger.info('Send proactive message ...');
                        this.client.sendMessage(msg.message, dmChannel.id, '');
                    }
                }
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.send, this);
            }
        });
    }
    // Send message back to Mattermost channel
    send(chatContextData, messages) {
        return __awaiter(this, void 0, void 0, function* () {
            // Print start log
            logger.start(this.send, this);
            try {
                // Get chat context data
                logger.debug(`Chat tool data sent to Mattermost server: ${Util_1.Util.dumpObject(chatContextData.context.chatTool, 2)}`);
                for (const msg of messages) {
                    // Process view to open dialog.
                    if (msg.type === "mattermost.dialog.open" /* IMessageType.MATTERMOST_DIALOG_OPEN */) {
                        yield this.client.openDialog(msg.message);
                        break;
                    }
                    // Send message back to channel
                    if (chatContextData.context.chatTool !== null) { // Conversation message
                        logger.info('Send conversation message ...');
                        this.client.sendMessage(msg.message, chatContextData.context.chatting.channel.id, chatContextData.context.chatTool.rootId);
                    }
                    else {
                        // Proactive message
                        logger.info('Send proactive message ...');
                        // Find channel if channel id is not provided.
                        let channelId = null;
                        if (chatContextData.context.chatting.channel.id === ''
                            && chatContextData.context.chatting.channel.name !== '') { // channel name is provided.
                            const channelInfo = yield this.client.getChannelByName(chatContextData.context.chatting.channel.name);
                            if (channelInfo === null) {
                                logger.error(`The specified MatterMost channel does not exist!\n`
                                    + JSON.stringify(chatContextData.context.chatting.channel, null, 2));
                                return;
                            }
                            logger.debug(`Target channel info: ${JSON.stringify(channelInfo, null, 2)}`);
                            channelId = channelInfo.id;
                        }
                        else { // channel id is provided.
                            channelId = chatContextData.context.chatting.channel.id;
                        }
                        logger.debug(`Target channel id: ${channelId}`);
                        this.client.sendMessage(msg.message, channelId, '');
                    }
                }
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.send, this);
            }
        });
    }
    // Process normal message
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    processMessage(rawMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.processMessage, this);
            /* Incoming message format from websocket
                    {
                    event: 'posted',
                    data: {
                        channel_display_name: 'Town Square',
                        channel_name: 'town-square',
                        channel_type: 'O',
                        mentions: '["ncy4cya8ojbk9m8gw3eefpie7y"]',
                        post: '{"id":"54cz6j6zejyxpgo9nb1a9m3p4o","create_at":1627025384926,"update_at":1627025384926,"edit_at":0,
                        "delete_at":0,"is_pinned":false,"user_id":"45oe76zzr78w3rugc5r3xss8cr","channel_id":"hj7byq55j3yfdr4y5dnizzzx6r",
                        "root_id":"","parent_id":"","original_id":"","message":"@blz  ad list","type":"","props":
                        {"disable_group_highlight":true},"hashtags":"","pending_post_id":"45oe76zzr78w3rugc5r3xss8cr:1627025384415",
                        "reply_count":0,"last_reply_at":0,"participants":null,"is_following":false,"metadata":{}}',
                        sender_name: '@nancy',
                        set_online: true,
                        team_id: 'jqwpiqng8tbri8u6w9twy31wiy'
                    },
                    broadcast: {
                        omit_users: null,
                        user_id: '',
                        channel_id: 'hj7byq55j3yfdr4y5dnizzzx6r',
                        team_id: ''
                    },
                    seq: 6
                    }
            */
            logger.debug(`Message is received from Mattermost server: ${Util_1.Util.dumpObject(rawMessage)}`);
            try {
                const messagePost = JSON.parse(rawMessage.data.post);
                // Ignore message from bot itself
                if (messagePost.user_id === this.botUser.id) {
                    return;
                }
                // Get cached user, if user has not been cached, query it.
                let user = this.users.get(messagePost.user_id);
                if (user === undefined) { // Not cached, query it.
                    user = yield this.client.getUserById(messagePost.user_id);
                }
                logger.debug(`User is ${JSON.stringify(user)}`);
                let chattingType = "unknown" /* IChattingType.UNKNOWN */;
                if (rawMessage.data.channel_type !== undefined && rawMessage.data.channel_type !== null) {
                    chattingType = this.client.getChattingType(rawMessage.data.channel_type);
                }
                else {
                    logger.error(`rawMessage.data.channel_type is undefined.`);
                }
                // If this is 1v1 chat, add "@botName" to match message.
                let receivedMessage = messagePost.message;
                if (chattingType === "personal" /* IChattingType.PERSONAL */ && !receivedMessage.trim().startsWith('@')) {
                    receivedMessage = `@${this.botUser.name} ${receivedMessage}`;
                }
                const chatContextData = {
                    'payload': {
                        'type': "message" /* IPayloadType.MESSAGE */,
                        'data': receivedMessage,
                    },
                    'context': {
                        'chatting': {
                            'bot': this.bot,
                            'type': chattingType,
                            'user': {
                                'id': messagePost.user_id,
                                'name': (user !== null) ? user.name : rawMessage.data.sender_name.trim().substring(1),
                                'email': (user !== null) ? user.email : '',
                            },
                            'channel': {
                                'id': messagePost.channel_id,
                                'name': rawMessage.data.channel_name,
                            },
                            'team': {
                                'id': rawMessage.data.team_id,
                                'name': '',
                            },
                            'tenant': {
                                'id': '',
                                'name': '',
                            },
                        },
                        'chatTool': {
                            'rootId': messagePost.root_id,
                        },
                    },
                };
                logger.debug(`Chat context data sent to chat bot: ${Util_1.Util.dumpObject(chatContextData, 2)}`);
                // Get listeners
                const listeners = this.bot.getListeners();
                // Match and process message
                for (const listener of listeners) {
                    const matchers = listener.getMessageMatcher().getMatchers();
                    for (const matcher of matchers) {
                        const matched = matcher.matcher(chatContextData);
                        if (matched) {
                            // Call message handler to process message
                            for (const handler of matcher.handlers) {
                                yield handler(chatContextData);
                            }
                        }
                    }
                }
            }
            catch (err) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(err.name), err));
            }
            finally {
                // Print end log
                logger.end(this.processMessage, this);
            }
        });
    }
    updateBotUser(user) {
        this.botUser = user;
    }
    addUser(id, user) {
        if (this.users.has(id)) {
            return;
        }
        this.users.set(id, user);
    }
    getUserById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.getUserById, this);
            let user = this.users.get(id);
            if (user === undefined) { // Not cached, query it.
                user = yield this.client.getUserById(id);
            }
            logger.end(this.getUserById, this);
            return user;
        });
    }
    getChannelById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.getChannelById, this);
            const channel = yield this.client.getChannelById(id);
            logger.end(this.getChannelById, this);
            return channel;
        });
    }
}
exports.MattermostMiddleware = MattermostMiddleware;
