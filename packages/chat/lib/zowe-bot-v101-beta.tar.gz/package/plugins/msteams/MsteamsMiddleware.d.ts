import { IChatContextData, IMessage } from '../../types';
import { TurnContext } from 'botbuilder';
import { CommonBot } from '../../CommonBot';
import { Middleware } from '../../Middleware';
export declare class MsteamsMiddleware extends Middleware {
    private botFrameworkAdapter;
    private botActivityHandler;
    constructor(bot: CommonBot);
    processTurnError(context: TurnContext, error: Error): Promise<void>;
    run(): Promise<void>;
    sendDirectMessage(chatContextData: IChatContextData, messages: IMessage[]): Promise<void>;
    send(chatContextData: IChatContextData, messages: IMessage[]): Promise<void>;
}
