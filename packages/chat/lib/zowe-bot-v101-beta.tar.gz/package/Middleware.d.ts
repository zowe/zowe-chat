import type { IChatContextData, IMessage } from './types';
import { CommonBot } from './CommonBot';
export declare class Middleware {
    protected bot: CommonBot;
    constructor(bot: CommonBot);
    run(): Promise<void>;
    sendDirectMessage(chatContextData: IChatContextData, messages: IMessage[]): Promise<void>;
    send(chatContextData: IChatContextData, messages: IMessage[]): Promise<void>;
}
