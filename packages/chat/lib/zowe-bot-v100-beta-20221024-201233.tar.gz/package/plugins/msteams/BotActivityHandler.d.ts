import type { NextFunction } from 'express';
import { IUser } from '../../types';
import { TurnContext, TeamsActivityHandler, ChannelInfo, TaskModuleRequest, TaskModuleResponse } from 'botbuilder';
import { IChattingType } from '../../types';
import { CommonBot } from '../../CommonBot';
import { MsteamsMiddleware } from './MsteamsMiddleware';
export declare class BotActivityHandler extends TeamsActivityHandler {
    private bot;
    private middleware;
    private serviceUrl;
    private channels;
    private users;
    constructor(bot: CommonBot, middleware: MsteamsMiddleware);
    processMessage(context: TurnContext, next: NextFunction): Promise<void>;
    updateConversation(context: TurnContext, next: NextFunction): Promise<void>;
    private cacheServiceUrl;
    handleTeamsTaskModuleFetch(context: TurnContext, taskModuleRequest: TaskModuleRequest): Promise<TaskModuleResponse>;
    handleTeamsTaskModuleSubmit(context: TurnContext, taskModuleRequest: TaskModuleRequest): Promise<TaskModuleResponse>;
    getServiceUrl(): Map<string, string>;
    findServiceUrl(channelId: string): string;
    getChannel(): ChannelInfo[];
    findChannelByName(name: string): ChannelInfo;
    findChannelById(id: string): ChannelInfo;
    getUser(id: string): IUser;
    addUser(id: string, user: IUser): boolean;
    getChattingType(type: string): IChattingType;
}
