"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlackBotLimit = void 0;
const BotLimit_1 = require("../../BotLimit");
class SlackBotLimit extends BotLimit_1.BotLimit {
    // Constructor
    constructor() {
        super();
        // Set Slack limit
        this.limit = {
            // Unit for MaxLength: character
            // Unit for MaxNumber: item
            'messageMaxLength': 40000,
            'blockIdMaxLength': 255,
            'actionBlockElementsMaxNumber': 25,
            'contextBlockElementsMaxNumber': 10,
            'headerBlockTextMaxLength': 150,
            'imageBlockUrlMaxLength': 3000,
            'imageBlockAltTextMaxLength': 2000,
            'imageBlockTitleTextMaxLength': 2000,
            'inputBlockLabelTextMaxLength': 2000,
            'inputBlockHintTextMaxLength': 2000,
            'sectionBlockTextMaxLength': 3000,
            'sectionBlockFieldsMaxNumber': 10,
            'sectionBlockFieldsTextMaxLength': 2000,
            'videoBlockAuthorNameMaxLength': 50,
            'videoBlockTitleTextMaxLength': 200,
        };
    }
}
exports.SlackBotLimit = SlackBotLimit;
