"use strict";
/*
* This program and the accompanying materials are made available under the terms of the
* Eclipse Public License v2.0 which accompanies this distribution, and is available at
* https://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Copyright Contributors to the Zowe Project.
*/
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MattermostClient = void 0;
const ws_1 = __importDefault(require("ws"));
const superagent_1 = __importDefault(require("superagent"));
const Logger_1 = require("../../utils/Logger");
const Util_1 = require("../../utils/Util");
const logger = Logger_1.Logger.getInstance();
class MattermostClient {
    constructor(middleware, option) {
        this.rejectUnauthorized = false;
        this.heartBeat = 60000; // It is in millisecond.
        this.autoReconnect = true;
        this.middleware = middleware;
        this.option = option;
        this.ws = null;
        this.teamId = null;
        this.lastPongTime = null;
        this.pongTimer = null;
        this.reconnectCount = 0;
        this.connectionStatus = "not_connected" /* IConnectionStatus.NOT_CONNECTED */;
        this.mattermostServerBaseUrl = `${this.option.protocol}://${this.option.hostName}:${this.option.port}${this.option.basePath}`;
        this.connect = this.connect.bind(this);
        this.getTeamId = this.getTeamId.bind(this);
        this.getChannelById = this.getChannelById.bind(this);
        this.getChannelByName = this.getChannelByName.bind(this);
        this.getUserById = this.getUserById.bind(this);
        this.openDialog = this.openDialog.bind(this);
        this.get = this.get.bind(this);
        this.post = this.post.bind(this);
        this.reconnect = this.reconnect.bind(this);
    }
    // Connect and authenticate to Mattermost server for both REST API and websocket.
    connect() {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.connect, this);
            try {
                if (this.connectionStatus === "connecting" /* IConnectionStatus.CONNECTING */) {
                    return;
                }
                this.connectionStatus = "connecting" /* IConnectionStatus.CONNECTING */;
                // First, authenticate by Mattermost web service API.
                const response = yield this.get(`${this.mattermostServerBaseUrl}/users/me`);
                logger.debug(Util_1.Util.dumpResponse(response));
                if (response.statusCode === 200) {
                    this.middleware.updateBotUser({ id: response.body.id, name: response.body.username, email: '' });
                    logger.debug(`Logged in through REST API as user ${response.body.username}`);
                    // Get bot's Team id.
                    yield this.getTeamId();
                    // Second, connect the WebSocket and authenticate with an authentication challenge.
                    const options = { rejectUnauthorized: this.rejectUnauthorized };
                    let webSocketUrl = undefined;
                    if (this.option.protocol === "https" /* IProtocol.HTTPS */) {
                        webSocketUrl = `${"wss" /* IProtocol.WSS */}://${this.option.hostName}:${this.option.port}${this.option.basePath}/websocket`;
                    }
                    else {
                        webSocketUrl = `${"ws" /* IProtocol.WS */}://${this.option.hostName}:${this.option.port}${this.option.basePath}/websocket`;
                    }
                    logger.debug(`The Websocket url is: ${webSocketUrl}`);
                    if (this.ws !== null && this.ws !== undefined) {
                        this.ws.terminate();
                        this.ws = null;
                    }
                    this.ws = new ws_1.default(webSocketUrl, options);
                    this.ws.on('error', this.onError.bind(this));
                    this.ws.on('open', this.onOpen.bind(this));
                    this.ws.on('message', this.onMessage.bind(this));
                    this.ws.on('ping', this.onPing.bind(this));
                    this.ws.on('pong', this.onPong.bind(this));
                    this.ws.on('close', this.onClose.bind(this));
                }
                else {
                    logger.error(`Failed to connect to Mattermost server:  ${response.statusMessage}`);
                    this.connectionStatus = "not_connected" /* IConnectionStatus.NOT_CONNECTED */;
                    this.reconnect();
                }
            }
            catch (error) {
                logger.error(Util_1.Util.dumpObject(error));
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(error.name), error));
            }
            finally {
                logger.end(this.connect, this);
            }
        });
    }
    // Reconnect to Mattermost server.
    reconnect() {
        try {
            if (this.connectionStatus === "reconnecting" /* IConnectionStatus.RECONNECTING */) {
                logger.debug('It has been reconnecting now.');
                return;
            }
            this.connectionStatus = "reconnecting" /* IConnectionStatus.RECONNECTING */;
            // Clear the ping/pong timer.
            if (this.pongTimer !== null) {
                clearInterval(this.pongTimer);
                this.pongTimer = null;
            }
            if (this.ws !== null) {
                this.ws.terminate();
                this.ws = null;
            }
            this.reconnectCount += 1;
            const reconnectTimeout = this.reconnectCount * 2000;
            logger.debug(`Reconnect to Mattermost server in ${reconnectTimeout / 1000} seconds.`);
            setTimeout(() => {
                logger.debug('Trying to reconnect to Mattermost server.');
                this.connect();
            }, reconnectTimeout);
        }
        catch (error) {
            logger.error(Util_1.Util.dumpObject(error));
            // Print exception stack
            logger.error(logger.getErrorStack(new Error(error.name), error));
        }
    }
    // Disconnect with Mattermost server.
    disconnect() {
        try {
            // Clear the ping/pong timer.
            if (this.pongTimer !== null) {
                clearInterval(this.pongTimer);
                this.pongTimer = null;
            }
            if (this.ws !== null) {
                this.ws.terminate();
            }
        }
        catch (error) {
            logger.error(Util_1.Util.dumpObject(error));
            // Print exception stack
            logger.error(logger.getErrorStack(new Error(error.name), error));
        }
    }
    onOpen() {
        try {
            logger.debug('On open event.');
            this.reconnectCount = 0; // Clear the reconnect count.
            this.connectionStatus = "alive" /* IConnectionStatus.ALIVE */;
            const authenticationChallenge = {
                seq: 1,
                action: 'authentication_challenge',
                data: {
                    token: this.option.botAccessToken,
                },
            };
            // Authenticate with an authentication challenge
            this.authenticate(authenticationChallenge);
            this.pongTimer = setInterval(() => {
                if (this.connectionStatus !== "alive" /* IConnectionStatus.ALIVE */) {
                    logger.error('The websocket is not alive now, try to reconnect.');
                    this.reconnect();
                    return;
                }
                if ((this.lastPongTime !== null && this.lastPongTime !== undefined)
                    && ((Date.now() - this.lastPongTime) > (3 * this.heartBeat))) {
                    logger.error(`It has been too long after receiving preview pong, try to reconnect.`);
                    this.connectionStatus = "expired" /* IConnectionStatus.EXPIRED */;
                    this.reconnect();
                    return;
                }
                logger.debug('Sending heart-beating ping to mattermost server.');
                this.ws.ping();
            }, this.heartBeat);
        }
        catch (error) {
            logger.error(Util_1.Util.dumpObject(error));
            // Print exception stack
            logger.error(logger.getErrorStack(new Error(error.name), error));
        }
    }
    // Receive Mattermost WebSocket events.
    onMessage(data) {
        logger.start(this.onMessage, this);
        try {
            const message = JSON.parse(data); // eslint-disable-line @typescript-eslint/no-explicit-any
            logger.debug(`Received message is ${Util_1.Util.dumpObject(message)}`);
            if (message.event !== undefined && message.event === 'posted') {
                this.middleware.processMessage(message);
            }
            else if (message.event !== undefined && message.event === 'hello') {
                // Once successfully authenticated, the Mattermost server will pass a hello WebSocket event containing server version over the connection.
                // So use the time of receiving hello event as the first pong time.
                this.lastPongTime = Date.now(); // Timestamp of previous pong.
            }
            else {
                // Add more event handling if they are needed in the future.
                /*
                    added_to_team
                    authentication_challenge
                    channel_converted
                    channel_created
                    channel_deleted
                    channel_member_updated
                    channel_updated
                    channel_viewed
                    config_changed
                    delete_team
                    direct_added
                    emoji_added
                    ephemeral_message
                    group_added
                    leave_team
                    license_changed
                    memberrole_updated
                    new_user
                    plugin_disabled
                    plugin_enabled
                    plugin_statuses_changed
                    post_deleted
                    post_edited
                    post_unread
                    preference_changed
                    preferences_changed
                    preferences_deleted
                    reaction_added
                    reaction_removed
                    response
                    role_updated
                    status_change
                    typing
                    update_team
                    user_added
                    user_removed
                    user_role_updated
                    user_updated
                    dialog_opened
                    thread_updated
                    thread_follow_changed
                    thread_read_changed
                */
            }
        }
        catch (error) {
            logger.error(Util_1.Util.dumpObject(error));
            // Print exception stack
            logger.error(logger.getErrorStack(new Error(error.name), error));
        }
        finally {
            logger.end(this.onMessage, this);
        }
    }
    onPong() {
        logger.debug('Received heart-beating pong from Mattermost server.');
        this.lastPongTime = Date.now(); //  Update latPongTime when receiving Pong event every time.
    }
    onPing() {
        logger.debug('Received heart-beating ping from Mattermost server.');
        this.ws.pong();
    }
    onClose(code, reason) {
        logger.debug(`On event close, the code is ${code} and reason is ${reason}.`);
        this.connectionStatus = "closed" /* IConnectionStatus.CLOSED */;
        if (this.autoReconnect) { // The connection is closed, try to connect.
            this.reconnect();
        }
    }
    onError(error) {
        this.connectionStatus = "error" /* IConnectionStatus.ERROR */;
        logger.error(`On event error: ${error}`);
    }
    // Send message to Mattermost channel, group or direct message through Mattermost web service Rest API posts.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    sendMessage(message, channelId, rootId) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.sendMessage, this);
            try {
                const postObject = {
                    message: message,
                    root_id: rootId,
                    channel_id: channelId,
                };
                if (typeof message === 'string') {
                    postObject.message = message;
                }
                else {
                    postObject.message = message.message;
                    if (message.props !== undefined) {
                        postObject.props = message.props;
                    }
                }
                logger.debug(`The postObject is ${Util_1.Util.dumpObject(postObject)}`);
                yield this.post(`${this.mattermostServerBaseUrl}/posts`)
                    .send(JSON.stringify(postObject));
            }
            catch (error) {
                logger.error(Util_1.Util.dumpObject(error));
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(error.name), error));
            }
            finally {
                logger.end(this.sendMessage, this);
            }
        });
    }
    // Send message to Mattermost server through the WebSocket.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    authenticate(message) {
        logger.start(this.authenticate, this);
        try {
            if (this.connectionStatus !== "alive" /* IConnectionStatus.ALIVE */) {
                logger.error('Could not send message because the websocket is not alive now.');
                return;
            }
            logger.debug(JSON.stringify(message));
            this.ws.send(JSON.stringify(message));
        }
        catch (error) {
            logger.error(Util_1.Util.dumpObject(error));
            // Print exception stack
            logger.error(logger.getErrorStack(new Error(error.name), error));
        }
        finally {
            logger.end(this.authenticate, this);
        }
    }
    // Open dialog
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    openDialog(payload) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.openDialog, this);
            try {
                yield this.post(`${this.mattermostServerBaseUrl}/actions/dialogs/open`)
                    .send(JSON.stringify(payload));
            }
            catch (error) {
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(error.name), error));
            }
            finally {
                logger.end(this.openDialog, this);
            }
        });
    }
    // Get Mattermost team Id for bot
    getTeamId() {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.getTeamId, this);
            try {
                const response = yield this.get(`${this.mattermostServerBaseUrl}/users/me/teams`);
                logger.debug(Util_1.Util.dumpResponse(response));
                if (response.statusCode === 200) {
                    for (const team of response.body) {
                        if (team.name.toLowerCase() === this.option.teamUrl.toLowerCase()) {
                            logger.debug(`Found team id: ${team.id}`);
                            this.teamId = team.id;
                        }
                    }
                }
                else {
                    logger.error(`Failed to get team id for bot user: ${response.statusMessage}`);
                }
            }
            catch (error) {
                logger.error(Util_1.Util.dumpObject(error));
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(error.name), error));
            }
            finally {
                logger.end(this.getTeamId, this);
            }
        });
    }
    // Get channel by channel id.
    getChannelById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.getChannelById, this);
            try {
                const response = yield this.get(`${this.mattermostServerBaseUrl}/channels/${id}`);
                if (response.statusCode === 200) {
                    const channel = {
                        id: response.body.id,
                        name: response.body.display_name,
                        chattingType: this.getChattingType(response.body.type),
                    };
                    return channel;
                }
                else {
                    logger.error(`Failed to get channel which id is ${id}: ${response.statusMessage}`);
                    return null;
                }
            }
            catch (error) {
                logger.error(Util_1.Util.dumpObject(error));
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(error.name), error));
            }
            finally {
                logger.end(this.getChannelById, this);
            }
        });
    }
    // Get channel by channel name.
    getChannelByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.getChannelByName, this);
            try {
                if (this.teamId === null) { // could not query channel by channel name without teamId.
                    logger.error('Could not get channel info without team id.');
                    return null;
                }
                const response = yield this.get(`${this.mattermostServerBaseUrl}/teams/${this.teamId}/channels/name/${name}`);
                if (response.statusCode === 200) {
                    const channel = {
                        id: response.body.id,
                        name: response.body.display_name,
                        chattingType: this.getChattingType(response.body.type),
                    };
                    return channel;
                }
                else {
                    logger.error(`Failed to get channel named ${name}: ${response.statusMessage}`);
                    return null;
                }
            }
            catch (error) {
                logger.error(Util_1.Util.dumpObject(error));
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(error.name), error));
            }
            finally {
                logger.end(this.getChannelByName, this);
            }
        });
    }
    getChattingType(type) {
        let chattingType = "unknown" /* IChattingType.UNKNOWN */;
        if (type == 'D') { // direct message
            chattingType = "personal" /* IChattingType.PERSONAL */;
        }
        else if (type == 'O') { // public channel
            chattingType = "publicChannel" /* IChattingType.PUBLIC_CHANNEL */;
        }
        else if (type == 'P') { // private channel
            chattingType = "privateChannel" /* IChattingType.PRIVATE_CHANNEL */;
        }
        else if (type == 'G') { // group chat
            chattingType = "group" /* IChattingType.GROUP */;
        }
        else {
            logger.warn(`Not supported channel type for the current Mattermost adapter.`);
        }
        return chattingType;
    }
    // Get user by user id.
    getUserById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.getUserById, this);
            try {
                const response = yield this.get(`${this.mattermostServerBaseUrl}/users/${id}`);
                logger.debug(Util_1.Util.dumpResponse(response));
                if (response.statusCode === 200) {
                    const user = { id: response.body.id, name: response.body.username, email: response.body.email };
                    this.middleware.addUser(response.body.id, user);
                    return user;
                }
                else {
                    logger.error(`Failed to get user info for userId ${id}: ${response.statusMessage}`);
                    return null;
                }
            }
            catch (error) {
                logger.error(Util_1.Util.dumpObject(error));
                // Print exception stack
                logger.error(logger.getErrorStack(new Error(error.name), error));
            }
            finally {
                logger.end(this.getUserById, this);
            }
        });
    }
    post(url) {
        logger.start(this.post, this);
        try {
            const agent = superagent_1.default.post(url)
                .set('Authorization', `BEARER ${this.option.botAccessToken}`)
                .set('Accept', 'application/json')
                .set('Content-Type', 'application/json');
            if (this.option.protocol === 'https') {
                agent.ca(this.option.tlsCertificate);
            }
            return agent;
        }
        catch (error) {
            logger.error(Util_1.Util.dumpObject(error));
            // Print exception stack
            logger.error(logger.getErrorStack(new Error(error.name), error));
        }
        finally {
            logger.end(this.get, this);
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    get(url) {
        return __awaiter(this, void 0, void 0, function* () {
            logger.start(this.get, this);
            const res = {}; // eslint-disable-line @typescript-eslint/no-explicit-any
            try {
                logger.debug(`url is ${url}`);
                const request = superagent_1.default.get(url)
                    .set('Authorization', `BEARER ${this.option.botAccessToken}`)
                    .set('Accept', 'application/json')
                    .set('Content-Type', 'application/json');
                if (this.option.protocol === 'https') {
                    request.ca(this.option.tlsCertificate);
                }
                const res = yield request;
                logger.debug(Util_1.Util.dumpResponse(res));
                return res;
            }
            catch (e) {
                if (e.timeout) {
                    res.statusCode = 408;
                    res.statusMessage = 'Request Timeout';
                }
                else {
                    res.statusCode = 500;
                    res.statusMessage = 'Internal Server Error';
                }
                logger.error(Util_1.Util.dumpResponse(e.response));
                logger.error(logger.getErrorStack(new Error(res.statusMessage), e));
                return res;
            }
            finally {
                logger.end(this.get, this);
            }
        });
    }
}
exports.MattermostClient = MattermostClient;
