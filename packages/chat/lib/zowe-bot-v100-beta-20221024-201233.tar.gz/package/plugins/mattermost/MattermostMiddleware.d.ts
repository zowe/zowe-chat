import { CommonBot } from '../../CommonBot';
import { Middleware } from '../../Middleware';
import { IChatContextData, IMessage, IUser, IChannel } from '../../types';
export declare class MattermostMiddleware extends Middleware {
    private client;
    private botUser;
    private users;
    private channels;
    constructor(bot: CommonBot);
    run(): Promise<void>;
    send(chatContextData: IChatContextData, messages: IMessage[]): Promise<void>;
    processMessage(rawMessage: Record<string, any>): Promise<void>;
    updateBotUser(user: IUser): void;
    addUser(id: string, user: IUser): void;
    getUserById(id: string): Promise<IUser>;
    getChannelById(id: string): Promise<IChannel>;
}
