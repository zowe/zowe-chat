import { ILogOption } from '../types';
export declare class Logger {
    private static instance;
    private logger;
    private option;
    private constructor();
    static getInstance(): Logger;
    getOption(): ILogOption;
    start(functionName: string | Record<string, any>, className?: string | Record<string, any>, fileName?: string): void;
    end(functionName: string | Record<string, any>, className?: string | Record<string, any>, fileName?: string): void;
    getErrorStack(newError: Error, caughtError: Error): string;
    debug(log: string): void;
    error(log: string): void;
    warn(log: string): void;
    info(log: string): void;
}
