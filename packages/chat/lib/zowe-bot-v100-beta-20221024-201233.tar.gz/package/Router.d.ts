import { IRoute, IRouteHandlerFunction } from './types';
import { CommonBot } from './CommonBot';
export declare class Router {
    protected bot: CommonBot;
    protected router: IRoute;
    constructor(bot: CommonBot);
    route(basePath: string, handler: IRouteHandlerFunction): Promise<void>;
    getRoute(): IRoute;
    setRoute(path: string, handler: IRouteHandlerFunction): void;
}
